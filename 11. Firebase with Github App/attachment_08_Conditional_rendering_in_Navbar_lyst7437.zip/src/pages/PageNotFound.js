import React from "react";

const PageNotFound = () => {
  return (
    <div>
      <h1>PageNotFound page</h1>
    </div>
  );
};

export default PageNotFound;
