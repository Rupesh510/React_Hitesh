//TODO: DONE: Create context: ContactContext
import { createContext } from "react";

export const ContactContext = createContext();
